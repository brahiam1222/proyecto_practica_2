<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <strong>Derechos Reservados
    </div>
    Copyright ©

    <?php
        echo date('Y');
    ?>

    <a href="<?php echo e(substr(url('/'), 0, -11)); ?>">Agroesco</a></strong>
</footer>
<?php /**PATH C:\xampp\htdocs\xampp\proyecto_practica_2\cms\resources\views/modulos/footer.blade.php ENDPATH**/ ?>