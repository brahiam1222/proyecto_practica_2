<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- ========== Start Section  PLUGIN CSS ========== -->
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
        integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/plugins/OverlayScrollbars.min.css">
    
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/ownstyle.css">

    
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/plugins/adminlte.min.css">


    
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

    <!-- ========== End Section PLUGIN CSS ========== -->





    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Document</title>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <?php echo $__env->make('modulos.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('modulos.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('modulos.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- ========== Start Section PLUGINS JS ========== -->

    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>

    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    
    <script src="https://kit.fontawesome.com/eeaede5d80.js" crossorigin="anonymous"></script>

    
    <script src="<?php echo e(url('/')); ?>/js/plugins/jquery.overlayScrollbars.min.js"></script>

    
    <script src="<?php echo e(url('/')); ?>/js/plugins/adminlte.js"></script>
    
    <script src="<?php echo e(url('/')); ?>/js/registroTerminacion.js"></script>


    <!-- ========== End Section PLUGINS JS ========== -->

</body>

</html>
<?php /**PATH C:\xampp\htdocs\xampp\cms\resources\views/plantilla.blade.php ENDPATH**/ ?>