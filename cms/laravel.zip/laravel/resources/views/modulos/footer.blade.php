<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <strong>Derechos Reservados
    </div>
    Copyright ©

    @php
        echo date('Y');
    @endphp

    <a href="{{ substr(url('/'), 0, -11) }}">Agroesco</a></strong>
</footer>
